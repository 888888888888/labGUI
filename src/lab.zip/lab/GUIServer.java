package lab;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.BevelBorder;


public class GUIServer extends JFrame implements ActionListener{
	
	private String dane = "";
	private static Connection conn = null;
	private int idGracz;

	private int counter;

	private static String wynik;
	private static String pytania = "";
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GUIServer() {
		
		initComponents();
	}
	
	/**
	 * metoda inicjuj�ca okno
	 */
	private void initComponents() {
		
		GridLayout layout = new GridLayout(0,1);
		
		JPanel pole = new JPanel();
		
		// ustawiam domyslne bilae tlo
        pole.setBackground(new java.awt.Color(255, 255, 255));
        pole.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        pole.setLayout(layout);
        pole.setPreferredSize(new Dimension(300, 100));
        
        GridLayout layout2 = new GridLayout(0,3);
        
        JPanel polaczenie = new JPanel();
        polaczenie.setLayout(layout2);
        
        TextField adress = new TextField();
        adress.setText("adress");
        TextField dataBaseName = new TextField();
        dataBaseName.setText("dataBase");
        TextField userName = new TextField();
        userName.setText("userName");
        
        polaczenie.add(adress);
        polaczenie.add(dataBaseName);
        polaczenie.add(userName);
        
        pole.add(polaczenie);
        
		JButton button = new JButton("PO��CZ Z BD");
		button.setActionCommand("ConnectDB");
		button.addActionListener(this);
		pole.add(button);
		button = new JButton("PYTANIA I ODP");
		button.setActionCommand("Pytania");
		button.addActionListener(this);
		pole.add(button);;
		add(pole);
        
		pack();
		setVisible(true);
 
	}
	
	public void buttonConnect(){
		if (ladujSterownik())
			System.out.print("sterownik OK");
		else
			System.exit(1);
		conn = connectToDatabase("127.0.0.1", "quiz", "root", "");
		if (conn != null)
			System.out.print(" polaczenie OK\n");
	}
	
	public void buttonPytania(){
	
		try {
			for (int i = 1; i <= 4; i++){
				odczytZBazyDanych(i);
				pytania += String.valueOf(i) + "."+ dane+"\n";
			}
			odczytPoprawnychOdpowiedzi();
			new GUIPytania(pytania, wynik);
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		// TODO Auto-generated method stub
		String cmd = e.getActionCommand();
		try {
			Method m = this.getClass().getDeclaredMethod("button"+cmd);// pobranie metody
			m.invoke(this);// wywo�anie metody
			
		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}
	
	public void odczytZBazyDanych(int numerPytania) throws IOException {

		try {

			java.sql.PreparedStatement statement = conn.prepareStatement("SELECT * FROM `pytanie` WHERE id = ?");
			statement.setInt(1, numerPytania);
			java.sql.ResultSet resultset = null;
			resultset = statement.executeQuery();
			if (resultset.next()) {
				dane = resultset.getString("pytanie");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static boolean ladujSterownik() {
		// LADOWANIE STEROWNIKA
		System.out.print("Sprawdzanie sterownika:");
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			return true;
		} catch (Exception e) {
			System.out.println("Blad przy ladowaniu sterownika bazy!");
			return false;
		}
	}
	
	public static Connection connectToDatabase(String adress, String dataBaseName, String userName, String password) {
		System.out.print("\nLaczenie z baza danych:");
		String baza = "jdbc:mysql://" + adress + "/" + dataBaseName;
		java.sql.Connection connection = null;
		try {
			connection = DriverManager.getConnection(baza, userName, password);
		} catch (SQLException e) {
			System.out.println("Blad przy ladowaniu sterownika bazy!");
			System.exit(1);
		}
		return connection;
	}
	
	public void odczytPoprawnychOdpowiedzi() throws IOException {

		try {

			java.sql.PreparedStatement statement = conn.prepareStatement("SELECT * FROM odpowiedziprawidlowe;");
			java.sql.ResultSet resultset = null;
			resultset = statement.executeQuery();

			java.sql.ResultSetMetaData metaData = resultset.getMetaData();
			int numcols = metaData.getColumnCount();

			wynik = "";

			while (resultset.next()) {
				for (int i = 1; i <= numcols; i++) {
					Object obj = resultset.getObject(i);
					if (obj != null)
						wynik += obj.toString() + " ";
					else
						wynik += " ";
				}
			}
			wynik += "\n";
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public static void main(String arg[]) throws ClassNotFoundException, 
		InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{

		for (UIManager.LookAndFeelInfo info : UIManager
				.getInstalledLookAndFeels()) {
			if ("Nimbus".equals(info.getName())) {
				UIManager.setLookAndFeel(info.getClassName());
				break;
			}
		new GUIServer();
		}
	}

}
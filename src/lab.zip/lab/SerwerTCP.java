package lab;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.Callable;

/**
 * W�tek serwera obsluguj�cy komunikacje klient-serwer oraz zwracjacy idGracza kt�ry zako�czy quiz 
 * @author Krystian K�dro�
 *
 */
public class SerwerTCP implements Callable<Integer>{

	private String dane = "";
	private Connection conn = null;
	private int idGracz;

	Socket mySocket;
	private int counter;

	private static String wynik;

	public SerwerTCP(Socket socket, int counter)
	// konstruktor
	{
		super();
		// konstruktor klasy Thread
		mySocket = socket;
		this.counter = counter;
	}

	/**
	 * Funkcja tworzaca rekord Gracz dla danego uzytkownik, pozwalajacy przeprowadzic dla niego quiz
	 * @param counter licznik bedacy jednoczesnie nickiem gracza (licznik odpowida liczbie aktywnych watkow)
	 * @return
	 */
	public boolean utworzGracza(int counter) {

		try {

			String nick = String.valueOf(counter);

			java.sql.PreparedStatement statement = conn.prepareStatement("INSERT INTO gracz (nick) VALUES (?);");
			statement.setString(1, nick);
			statement.execute();

			statement = conn.prepareStatement("SELECT id_gracz FROM gracz WHERE nick = ?;");
			statement.setString(1, nick);

			java.sql.ResultSet resultset = null;
			resultset = statement.executeQuery();
			while (resultset.next()) {
				idGracz = resultset.getInt("id_gracz");
			}
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}

	}

	/**
	 * Funkcja odczytujaca pytania z bazy danych
	 * @param nrPytanie  jest to numer pytania jakie chcemy odczytac
	 * @throws IOException
	 */
	public void odczytZBazyDanych(int numerPytania) throws IOException {

		try {

			java.sql.PreparedStatement statement = conn.prepareStatement("SELECT * FROM `pytanie` WHERE id = ?");
			statement.setInt(1, numerPytania);
			java.sql.ResultSet resultset = null;
			resultset = statement.executeQuery();
			if (resultset.next()) {
				dane = resultset.getString("pytanie");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * Funkcja zapisujaca odpowiedz gracza do pliku
	 * @param odp jest to String bedacy odpowiedzia gracza
	 * @param numerPytania jest to numer pytania na ktore gracz odpowiedzial
	 * @return
	 */
	public boolean zapisDoBazyDanych(String odp, int numerPytania) {
		PreparedStatement prepStmt;
		try {

			prepStmt = conn.prepareStatement("INSERT INTO odpowiedzigracza (id_gracz, id, odpowiedz) VALUES (?,?,?);",
					Statement.RETURN_GENERATED_KEYS);
			prepStmt.setInt(1, idGracz);
			prepStmt.setInt(2, numerPytania);
			prepStmt.setString(3, odp);
			prepStmt.execute();

			return true;
		} catch (SQLException e) {

			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Funkcja inicjalizujaca sterownik do bazyDanych
	 * @return true/false w zaleznosci czy udalo sie zczytac sterownik czy nie
	 */
	public boolean ladujSterownik() {
		// LADOWANIE STEROWNIKA
		System.out.print("Sprawdzanie sterownika:");
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			return true;
		} catch (Exception e) {
			System.out.println("Blad przy ladowaniu sterownika bazy!");
			return false;
		}
	}

	/**
	 * Funkacja ��cz�ca si� z baz� danych
	 * @param adress 
	 * @param dataBaseName
	 * @param userName
	 * @param password
	 * @return uchwyt do polaczenia
	 */
	public Connection connectToDatabase(String adress, String dataBaseName, String userName, String password) {
		System.out.print("\nLaczenie z baza danych:");
		String baza = "jdbc:mysql://" + adress + "/" + dataBaseName;
		java.sql.Connection connection = null;
		try {
			connection = DriverManager.getConnection(baza, userName, password);
		} catch (SQLException e) {
			System.out.println("Blad przy ladowaniu sterownika bazy!");
			System.exit(1);
		}
		return connection;
	}

	/**
	 * Metoda odczytujaca odpowiedzi gracza, aby pozniej wyslac mu je po zakonczeniu quizu
	 * @throws IOException
	 */
	public void odczytOdpowiedziGracza() throws IOException {

		try {

			java.sql.PreparedStatement statement = conn
					.prepareStatement("SELECT * FROM odpowiedzigracza where id_gracz = ?;");
			statement.setInt(1, idGracz);
			java.sql.ResultSet resultset = null;
			resultset = statement.executeQuery();

			java.sql.ResultSetMetaData metaData = resultset.getMetaData();
			int numcols = metaData.getColumnCount();

			wynik = " ";

			while (resultset.next()) {
				for (int i = 3; i <= numcols; i++) {
					Object obj = resultset.getObject(i);
					if (obj != null)
						wynik += " " + obj.toString() + " |";
					else
						wynik += " ";
				}
			}
			wynik += "\n";
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	/**
	 * Metoda odczytujaca poprawne odpowiedzi, aby pozniej wyslac mu je po zakonczeniu quizu
	 * @throws IOException
	 */
	public void odczytPoprawnychOdpowiedzi() throws IOException {

		try {

			java.sql.PreparedStatement statement = conn.prepareStatement("SELECT * FROM odpowiedziprawidlowe;");
			java.sql.ResultSet resultset = null;
			resultset = statement.executeQuery();

			java.sql.ResultSetMetaData metaData = resultset.getMetaData();
			int numcols = metaData.getColumnCount();

			wynik = " ";

			while (resultset.next()) {
				for (int i = 1; i <= numcols; i++) {
					Object obj = resultset.getObject(i);
					if (obj != null)
						wynik += " " + obj.toString() + " |";
					else
						wynik += " ";
				}
			}
			wynik += "\n";
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	/**
	 * Metoda obsulugujaca polaczenie Klient-Serwer
	 * @param odSerwera
	 * @param odKlienta
	 * @param i
	 * @throws IOException
	 */
	private void komunikacjaKlientSerwer(DataOutputStream odSerwera, BufferedReader odKlienta, int i) throws IOException {
		
		String odpowiedz;
		
		odczytZBazyDanych(i);
		dane = dane + '\n';
		odSerwera.writeBytes(dane);

		odpowiedz = odKlienta.readLine();
		if (zapisDoBazyDanych(odpowiedz, i)) {
			System.out.println("Zapisano "+ i +"! idGracza-> " + idGracz);
		}	
	}
	
	/**
	 * Funkcja wysylajaca odpowiedzi gracza oraz porpawne odpowiedzi do uzytkownika
	 * @param odSerwera
	 * @throws IOException
	 */
	private void wyslijOdpowiedzi(DataOutputStream odSerwera) throws IOException {
		
		// Wysy�anie wynikow quzia do uzytkownika
		wynik = "KONIEC \n";
		odSerwera.writeBytes(wynik);
		
	}

	/**
	 * Metoda glowna watku obslugujaca powysze funkcjonalnosci
	 * @param argv
	 * @throws Exception
	 */
	public Integer call() {

		try {
			
			new DataBase();
			BufferedReader odKlienta = new BufferedReader(new InputStreamReader(mySocket.getInputStream()));
			DataOutputStream odSerwera = new DataOutputStream(mySocket.getOutputStream());

			if (ladujSterownik())
				System.out.print(" sterownik OK");
			else
				System.exit(1);
			conn = connectToDatabase("127.0.0.1", "quiz", "root", "");
			if (conn != null)
				System.out.print(" polaczenie OK\n");

			if (utworzGracza(counter)) {
				System.out.println("Gracz zosta� utworzony o id =" + idGracz + "!");
			} else {
				System.out.println("Blad podczas tworzenia gracza!");
			}
			
			for(int i = 1; i <= 4; i++){
				
				komunikacjaKlientSerwer(odSerwera, odKlienta, i);
			}
			
			wyslijOdpowiedzi(odSerwera);
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}
		return idGracz;
	}
}
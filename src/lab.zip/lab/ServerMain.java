package lab;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

/**
 * Metoda Main serwera tworzaca nowe watki dla kazdego uzytkownika
 * @author Krystian K�dro�
 *
 */
public class ServerMain {
	
	private static int counter = -1;
	
	public static void main(String args[]) {
		try {
			/*
			 * tworzymy socket bez drugiego ko�ca ...
			 */
			@SuppressWarnings("resource")
			ServerSocket serverSocket = new ServerSocket(4322);
			ExecutorService exec = Executors.newFixedThreadPool(10);
			
			while (true) {
				/*
				 * czekamy na zg�oszenie klienta ...
				 */
				System.out.println("Czekam na polaczenie....");
				Socket socket = serverSocket.accept();
				counter++;
				/*
				 * tworzymy w�tek dla danego po��czenia i uruchamiamy jego
				 * quiz
				 */
	
				exec.execute( new FutureTask<Integer>(new SerwerTCP(socket, counter)){
					public void done(){
						
						try {
							
							System.out.println("Koniec quizu dla gracz o id= "+get());
						} catch (InterruptedException | ExecutionException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});	
			}
		} catch (Exception e) {
			System.err.println(e);
		}
	}
}

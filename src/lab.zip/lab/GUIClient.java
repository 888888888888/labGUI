package lab;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.Socket;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.BevelBorder;


public class GUIClient extends JFrame implements ActionListener{

	TextField odpowiedz;
	JTextArea pytanie;
	
	DataOutputStream doSerwera;
	BufferedReader pytanieSerwera;
	
	String pytanieText;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GUIClient() {
		
		connectToServer();
		odbierzPytanie();
		initComponents();
	}
	
	private void connectToServer() {
		// TODO Auto-generated method stub
		
		try {
			
			@SuppressWarnings("resource")
			Socket gniazdo = new Socket("localhost", 4322);
			
			doSerwera = new DataOutputStream(gniazdo.getOutputStream());
			pytanieSerwera = new BufferedReader(new InputStreamReader(gniazdo.getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void odbierzPytanie(){
		
		try {
			pytanieText = pytanieSerwera.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * metoda inicjuj�ca okno
	 */
	private void initComponents() {
		
		GridLayout layout = new GridLayout(0,1);
		
		JPanel pole = new JPanel();
		
		// ustawiam domyslne bilae tlo
        pole.setBackground(new java.awt.Color(255, 255, 255));
        pole.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
        pole.setLayout(layout);
		
        pytanie = new JTextArea();
        pytanie.setText(pytanieText);
        
        pole.add(pytanie);
        
        odpowiedz = new TextField();
        odpowiedz.setPreferredSize(new Dimension(200, 20));
        
        pole.add(odpowiedz);
        
        add(pole);
        
        // nowy panel gdzie dodamy nasze klawisze (start i exit)
        JPanel menu = new JPanel();
		JButton button = new JButton("Wyslij");
		button.setActionCommand("Start");
		button.addActionListener(this);
		menu.add(button);
		add(menu, "South");
        
		//pozniej napewno bedzie trzeba upakowac to w jakis Layout
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
 
	}
	
	public void buttonStart(String odpoweidz){
		
		try {
			
			doSerwera.writeBytes(odpoweidz + '\n');
			odbierzPytanie();
			pytanie.setText(pytanieText);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		// TODO Auto-generated method stub
		String cmd = e.getActionCommand();
		String text = odpowiedz.getText();
	
		try {
				
			Method m = this.getClass().getDeclaredMethod("button"+cmd, new Class[]{String.class});// pobranie metody
			m.invoke(this,text);// wywo�anie metody
			
		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}
	
	public static void main(String arg[]) throws ClassNotFoundException, 
		InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException{
		
		for (UIManager.LookAndFeelInfo info : UIManager
				.getInstalledLookAndFeels()) {
			if ("Nimbus".equals(info.getName())) {
				UIManager.setLookAndFeel(info.getClassName());
				break;
			}
		new GUIClient();
		}
	}

}
